import { useState } from "react";

export default function Home() {
  const [file, setFile] = useState(null);
  const [clips, setClips] = useState([]);
  const [loading, setLoading] = useState(false);

  const upload = async () => {
    if (!file) return;
    setLoading(true);

    const form = new FormData();
    form.append("video", file);

    const res = await fetch("http://localhost:5000/upload", {
      method: "POST",
      body: form
    });

    const data = await res.json();
    setClips(data.clips || []);
    setLoading(false);
  };

  return (
    <main style={{ padding: 40 }}>
      <h1>Klap Clone (MVP)</h1>

      <input
        type="file"
        accept="video/*"
        onChange={e => setFile(e.target.files?.[0] || null)}
      />

      <br /><br />
      <button onClick={upload}>Upload & Generate Clips</button>

      {loading && <p>Processing video...</p>}

      <div style={{ marginTop: 20 }}>
        {clips.map((c, i) => (
          <video key={i} src={`http://localhost:5000/${c}`} controls width={200} />
        ))}
      </div>
    </main>
  );
}
